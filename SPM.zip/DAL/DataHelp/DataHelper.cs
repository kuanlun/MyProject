﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using Oracle.ManagedDataAccess.Client;
using System.Configuration;

namespace DAL
{
    class DataHelper
    {
        private static string SconnString = ConfigurationManager.ConnectionStrings["SDB"].ToString();

        /// <summary>
        /// 增、删、改
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="sPara">参数组，没有可传null</param>
        /// <returns>返回受影响的行数</returns>
        public static int UPdate(string sql, SqlParameter[] sPara)
        {
            SqlConnection sconn = new SqlConnection(SconnString);
            SqlCommand scmd = new SqlCommand(sql,sconn);
            if (sPara != null)
            {
                scmd.Parameters.AddRange(sPara);
            }
            try
            {
                sconn.Open();
                return scmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                sconn.Close();
            }
        }

        /// <summary>
        /// 查询返回单一结果
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="sPara">参数组，没有可传NULL</param>
        /// <returns>返回每一行第一列</returns>
        public static object GetSingle(string sql,SqlParameter[] sPara)
        {
            SqlConnection sconn = new SqlConnection(SconnString);
            SqlCommand scmd = new SqlCommand(sql, sconn);
            if (sPara != null)
            {
                scmd.Parameters.AddRange(sPara);
            }
            try
            {
                sconn.Open();
                return scmd.ExecuteScalar();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                sconn.Close();
            }
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="sql">SQL语句</param>
        /// <param name="sPara">参数组，没有可传null</param>
        /// <returns>SqlDataReader</returns>
        public static SqlDataReader GetReader(string sql,SqlParameter[] sPara)
        {
            SqlConnection sconn = new SqlConnection(SconnString);
            SqlCommand scmd = new SqlCommand(sql, sconn);
            if (sPara!=null)
            {
                scmd.Parameters.AddRange(sPara);
            }
            try
            {
                sconn.Open();
                return scmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                sconn.Close();
                throw ex;
            }
        }

    }
}
