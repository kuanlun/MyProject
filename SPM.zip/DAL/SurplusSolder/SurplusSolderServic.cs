﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using Models;

namespace DAL
{
    public class SurplusSolderServic
    {
        /// <summary>
        /// 条码查出最近一次的锡䯧状态
        /// </summary>
        /// <param name="code">条码编号</param>
        /// <returns></returns>
        public object GetStatusByBarcode(string code)
        {
            string sql = "select status from SolderPaste_Transaction where SolderID=@SolderID order by TranTime desc";
            SqlParameter[] sPar = new SqlParameter[]
            {
                new SqlParameter("@SolderID",code)
            };
            try
            {
                return DataHelper.GetSingle(sql, sPar);
            }
            catch (SqlException ex)
            {

                throw new Exception("数据库出现异常，具体为：" + ex);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// 写入到数据据
        /// </summary>
        /// <param name="objSS">类</param>
        /// <returns></returns>
        public int InsertToDB(SurplusSolder objSS)
        {
            string sql = "insert into SolderPaste_Transaction (SolderID,Status,TranTime,UserID,ReMark) values(@SolderID,@Status,@TranTime,@UserID,@ReMark)";
            SqlParameter[] sPar = new SqlParameter[]
            {
                new SqlParameter("SolderID",objSS.SolderID),
                new SqlParameter("@Status",objSS.Status),
                new SqlParameter("@TranTime",objSS.TranTime),
                new SqlParameter("@UserID",objSS.UserID),
               // new SqlParameter("@Loc",objSS.Loc),
                new SqlParameter("@ReMark",objSS.ReMark)           

            };
            try
            {
                return DataHelper.UPdate(sql, sPar);
            }
            catch (SqlException ex)
            {

                throw new Exception("数据库出现异常，错误信息为：" + ex);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// 取得二次回库锡䯧
        /// </summary>
        /// <returns>SurplusSolder類</returns>
        public SurplusSolder GetSurplusSolder()
        {
            string sql = "select SolderID from SolderPaste_Transaction where Status='7' and ReMark='T'";
            
            SurplusSolder objSurplusSolder = null;
            SqlDataReader read = DataHelper.GetReader(sql, null);
            if (read.Read())
            {
                objSurplusSolder = new SurplusSolder()
                {
                    SolderID=read["SolderID"].ToString()
                };
            }
            read.Close();
            return objSurplusSolder;
        }

        /// <summary>
        /// 根据锡膏条码查询出回库锡膏
        /// </summary>
        /// <param name="strId">錫膏條碼</param>
        /// <returns>SurplusSolder類</returns>
        public SurplusSolder GetBySolderID(string strId)
        {
            string sql = "select SolderID from SolderPaste_Transaction where Status='7' and ReMark='T' and SolderID=@SolderID";
            SqlParameter[] sPar = new SqlParameter[]
            {
                new SqlParameter("@SolderID",strId)
            };
            SurplusSolder objSurplusSolder = null;
            SqlDataReader read = DataHelper.GetReader(sql, sPar);
            if (read.Read())
            {
                objSurplusSolder = new SurplusSolder()
                {
                    SolderID = read["SolderID"].ToString()
                };
            }
            read.Close();
            return objSurplusSolder;
        }
    }
}
