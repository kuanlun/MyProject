﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    [Serializable]
    public class SurplusSolder
    {
        public string SolderID { get; set; }
        public string Status { get; set; }
        public DateTime TranTime { get; set; }
        public string UserID { get; set; }
        public string Loc { get; set; }
        public string ReMark { get; set; }
    }
}
